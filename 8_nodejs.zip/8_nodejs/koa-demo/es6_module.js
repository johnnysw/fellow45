export default {
    sayHello(){
        console.log('say hi');
    }
}