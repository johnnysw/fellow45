// let xx = require('./4_moduleA');

// let Person = require('./6_moduleB')

// let p1 = new Person('lisi', 23);
// console.log(p1);


// console.log(  xx(3,4)   );

// console.log(xx.add(3,4));
// console.log(xx.minus(5,4));

// console.log(  add(3,4)  )
// console.log(  add(2,4)  )

// let http = require('./node_modules/http-request/index');

let http = require('http-request2');

http.get('www.baidu.com');
http.post('www.qq.com');