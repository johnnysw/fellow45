exports.add = function(a, b){
    return a + b;
}

exports.minus = function(a, b){
    return a - b;
}

module.exports = function (a, b) {
  return a + b;
};
