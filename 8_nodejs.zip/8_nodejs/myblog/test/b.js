

module.exports = {
    fn1: function(){
        console.log('haha');
    }
}