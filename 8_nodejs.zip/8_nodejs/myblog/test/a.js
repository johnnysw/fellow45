let obj = require('./b')

function test(fn){
    fn();
}

test(   obj.fn1  );